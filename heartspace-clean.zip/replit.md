# HeartSpace - Mental Health Support Platform

## Overview

HeartSpace is a compassionate mental health platform designed to provide emotional support through multiple channels. The application combines AI-powered emotional assistance, peer support communities, professional mental health resources, and self-care tools in a safe, judgment-free environment. Built as a full-stack web application, HeartSpace emphasizes privacy, accessibility, and emotional wellness with a warm, calming user experience.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **React + TypeScript SPA**: Single-page application built with React 18 and TypeScript for type safety
- **Vite Build System**: Fast development server and optimized production builds
- **Wouter Routing**: Lightweight client-side routing without React Router dependencies
- **shadcn/ui Component Library**: Modern, accessible UI components built on Radix UI primitives
- **Tailwind CSS**: Utility-first styling with custom CSS variables for theming
- **TanStack Query**: Data fetching, caching, and synchronization with the backend
- **Theme System**: Light/dark mode support with persistent user preferences

### Backend Architecture
- **Express.js Server**: RESTful API server with middleware for authentication and logging
- **PostgreSQL Database**: Primary data storage using Neon serverless PostgreSQL
- **Drizzle ORM**: Type-safe database operations with schema management
- **Session-based Authentication**: Secure user sessions with PostgreSQL session storage
- **Modular Route Structure**: Organized API endpoints for different feature domains

### Database Design
- **User Management**: User profiles with OAuth integration support
- **Mood Tracking**: Time-series mood entries with notes and analytics
- **Community Features**: Groups, posts, replies with engagement metrics
- **Chat System**: AI conversation sessions and message history
- **Professional Directory**: Mental health provider listings and contact information

### Authentication & Authorization
- **Replit Auth Integration**: OAuth-based authentication using Replit's identity provider
- **Session Management**: Secure session storage with PostgreSQL backend
- **Protected Routes**: Client and server-side route protection for authenticated users
- **User Context**: React hooks for accessing authentication state throughout the application

### AI Integration
- **OpenAI GPT-4o**: Advanced language model for empathetic conversation
- **Emotional Intelligence**: Mood detection and appropriate response generation
- **Support Level Assessment**: Risk evaluation for appropriate intervention
- **Personalized Content**: Dynamic quote generation and activity suggestions

### Data Flow Patterns
- **Client-Server Communication**: RESTful API with JSON request/response format
- **Real-time Features**: WebSocket preparation for future chat enhancements
- **State Management**: React Query for server state, React Context for client state
- **Error Handling**: Comprehensive error boundaries and user-friendly error messages

### Security & Privacy
- **Data Encryption**: Secure transmission and storage of sensitive information
- **Anonymous Options**: Community participation without revealing personal identity
- **Session Security**: HTTP-only cookies with secure flags
- **Input Validation**: Zod schema validation on both client and server

## External Dependencies

### Database & Infrastructure
- **Neon PostgreSQL**: Serverless PostgreSQL database hosting
- **Replit Hosting**: Development and deployment platform

### AI & ML Services
- **OpenAI API**: GPT-4o model for conversational AI and content generation
- **OpenAI Embeddings**: Future implementation for semantic search and content matching

### Authentication
- **Replit Auth**: OAuth identity provider integration
- **OpenID Connect**: Standard authentication protocol implementation

### Frontend Libraries
- **React Ecosystem**: React 18, React DOM, React Query for data management
- **UI Components**: Radix UI primitives, shadcn/ui component library
- **Styling**: Tailwind CSS, class-variance-authority for component variants
- **Utilities**: date-fns for date formatting, clsx for conditional classes

### Development Tools
- **TypeScript**: Static type checking and enhanced developer experience
- **Vite**: Fast build tool with HMR and optimized bundling
- **ESBuild**: Fast JavaScript bundler for server-side code
- **Drizzle Kit**: Database schema management and migrations

### Monitoring & Analytics
- **Runtime Error Tracking**: Vite plugin for development error reporting
- **Performance Monitoring**: Built-in request logging and timing