import {
  users,
  moodEntries,
  communityGroups,
  communityPosts,
  communityReplies,
  chatSessions,
  chatMessages,
  professionals,
  type User,
  type UpsertUser,
  type MoodEntry,
  type InsertMoodEntry,
  type CommunityGroup,
  type CommunityPost,
  type InsertCommunityPost,
  type CommunityReply,
  type InsertCommunityReply,
  type ChatSession,
  type InsertChatSession,
  type ChatMessage,
  type InsertChatMessage,
  type Professional,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";

export interface IStorage {
  // User operations - required for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Mood tracking operations
  createMoodEntry(moodEntry: InsertMoodEntry): Promise<MoodEntry>;
  getUserMoodEntries(userId: string, limit?: number): Promise<MoodEntry[]>;
  
  // Community operations
  getCommunityGroups(): Promise<CommunityGroup[]>;
  getCommunityPosts(groupId: string, limit?: number): Promise<CommunityPost[]>;
  createCommunityPost(post: InsertCommunityPost): Promise<CommunityPost>;
  getCommunityReplies(postId: string): Promise<CommunityReply[]>;
  createCommunityReply(reply: InsertCommunityReply): Promise<CommunityReply>;
  incrementPostHearts(postId: string): Promise<void>;
  
  // Chat operations
  createChatSession(session: InsertChatSession): Promise<ChatSession>;
  getUserChatSessions(userId: string): Promise<ChatSession[]>;
  getChatMessages(sessionId: string): Promise<ChatMessage[]>;
  addChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  
  // Professional operations
  getProfessionals(filters?: { specialization?: string; location?: string }): Promise<Professional[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations - required for Replit Auth
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Mood tracking operations
  async createMoodEntry(moodEntry: InsertMoodEntry): Promise<MoodEntry> {
    const [entry] = await db.insert(moodEntries).values(moodEntry).returning();
    return entry;
  }

  async getUserMoodEntries(userId: string, limit = 30): Promise<MoodEntry[]> {
    return await db
      .select()
      .from(moodEntries)
      .where(eq(moodEntries.userId, userId))
      .orderBy(desc(moodEntries.createdAt))
      .limit(limit);
  }

  // Community operations
  async getCommunityGroups(): Promise<CommunityGroup[]> {
    return await db.select().from(communityGroups).orderBy(desc(communityGroups.memberCount));
  }

  async getCommunityPosts(groupId: string, limit = 20): Promise<CommunityPost[]> {
    return await db
      .select()
      .from(communityPosts)
      .where(eq(communityPosts.groupId, groupId))
      .orderBy(desc(communityPosts.createdAt))
      .limit(limit);
  }

  async createCommunityPost(post: InsertCommunityPost): Promise<CommunityPost> {
    const [newPost] = await db.insert(communityPosts).values(post).returning();
    return newPost;
  }

  async getCommunityReplies(postId: string): Promise<CommunityReply[]> {
    return await db
      .select()
      .from(communityReplies)
      .where(eq(communityReplies.postId, postId))
      .orderBy(desc(communityReplies.createdAt));
  }

  async createCommunityReply(reply: InsertCommunityReply): Promise<CommunityReply> {
    const [newReply] = await db.insert(communityReplies).values(reply).returning();
    
    // Increment reply count on the post
    await db
      .update(communityPosts)
      .set({ replyCount: sql`${communityPosts.replyCount} + 1` })
      .where(eq(communityPosts.id, reply.postId));
    
    return newReply;
  }

  async incrementPostHearts(postId: string): Promise<void> {
    await db
      .update(communityPosts)
      .set({ heartCount: sql`${communityPosts.heartCount} + 1` })
      .where(eq(communityPosts.id, postId));
  }

  // Chat operations
  async createChatSession(session: InsertChatSession): Promise<ChatSession> {
    const [newSession] = await db.insert(chatSessions).values(session).returning();
    return newSession;
  }

  async getUserChatSessions(userId: string): Promise<ChatSession[]> {
    return await db
      .select()
      .from(chatSessions)
      .where(eq(chatSessions.userId, userId))
      .orderBy(desc(chatSessions.updatedAt));
  }

  async getChatMessages(sessionId: string): Promise<ChatMessage[]> {
    return await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.sessionId, sessionId))
      .orderBy(chatMessages.createdAt);
  }

  async addChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const [newMessage] = await db.insert(chatMessages).values(message).returning();
    
    // Update session's updatedAt timestamp
    await db
      .update(chatSessions)
      .set({ updatedAt: new Date() })
      .where(eq(chatSessions.id, message.sessionId));
    
    return newMessage;
  }

  // Professional operations
  async getProfessionals(filters?: { specialization?: string; location?: string }): Promise<Professional[]> {
    let whereConditions = [];
    
    if (filters?.specialization && filters.specialization !== 'All Specializations') {
      whereConditions.push(sql`${professionals.specialties} ILIKE ${'%' + filters.specialization + '%'}`);
    }
    
    if (filters?.location && filters.location !== 'Online Sessions') {
      whereConditions.push(sql`${professionals.location} ILIKE ${'%' + filters.location + '%'}`);
    }
    
    if (whereConditions.length > 0) {
      return await db
        .select()
        .from(professionals)
        .where(and(...whereConditions))
        .orderBy(desc(professionals.rating));
    }
    
    return await db
      .select()
      .from(professionals)
      .orderBy(desc(professionals.rating));
  }
}

export const storage = new DatabaseStorage();
