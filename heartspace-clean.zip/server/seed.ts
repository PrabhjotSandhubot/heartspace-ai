import { db } from "./db";
import { communityGroups, professionals } from "@shared/schema";

export async function seedDatabase() {
  try {
    console.log("Seeding database...");

    // Seed community groups
    const groups = [
      {
        name: "Anxiety Support",
        description: "A safe space to share anxiety experiences and coping strategies.",
        category: "anxiety",
        memberCount: 2847,
      },
      {
        name: "Grief & Loss",
        description: "Support for those navigating grief and healing from loss.",
        category: "grief", 
        memberCount: 1523,
      },
      {
        name: "Daily Motivation",
        description: "Positive vibes and encouragement to brighten your day.",
        category: "motivation",
        memberCount: 4192,
      },
      {
        name: "Depression Support", 
        description: "Understanding and support for those experiencing depression.",
        category: "depression",
        memberCount: 3156,
      },
      {
        name: "Relationship Challenges",
        description: "Navigate relationship difficulties with peer support.",
        category: "relationships",
        memberCount: 2789,
      },
      {
        name: "Work Stress",
        description: "Coping with workplace stress and burnout together.",
        category: "stress",
        memberCount: 1945,
      },
    ];

    for (const group of groups) {
      await db.insert(communityGroups).values(group).onConflictDoNothing();
    }

    // Seed mental health professionals
    const professionalsData = [
      {
        name: "Dr. Sarah Chen",
        credentials: "Licensed Clinical Psychologist",
        specialties: "Anxiety, Depression, Trauma Recovery",
        location: "Online & New York, NY",
        isOnlineAvailable: true,
        rating: 49, // 4.9 stars (stored as 49/10)
        reviewCount: 127,
        bio: "Dr. Chen specializes in anxiety, depression, and trauma recovery with over 8 years of experience helping individuals find their path to wellness.",
        yearsExperience: 8,
        profileImageUrl: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=150&h=150&fit=crop&crop=face",
      },
      {
        name: "Dr. Michael Rodriguez",
        credentials: "Licensed Marriage & Family Therapist", 
        specialties: "Relationship Counseling, Grief Support, Stress Management",
        location: "Online & Los Angeles, CA",
        isOnlineAvailable: true,
        rating: 48, // 4.8 stars
        reviewCount: 89,
        bio: "Dr. Rodriguez brings 12+ years of experience in relationship counseling, grief support, and stress management to help individuals and couples thrive.",
        yearsExperience: 12,
        profileImageUrl: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=150&h=150&fit=crop&crop=face",
      },
      {
        name: "Dr. Emily Johnson",
        credentials: "Licensed Clinical Social Worker",
        specialties: "Trauma Therapy, Addiction Recovery, Mindfulness-Based Interventions",
        location: "Online Only",
        isOnlineAvailable: true,
        rating: 50, // 5.0 stars
        reviewCount: 156,
        bio: "Dr. Johnson specializes in trauma therapy, addiction recovery, and mindfulness-based interventions with 15+ years of experience in clinical practice.", 
        yearsExperience: 15,
        profileImageUrl: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=150&h=150&fit=crop&crop=face",
      },
      {
        name: "Dr. James Park",
        credentials: "Licensed Professional Counselor",
        specialties: "ADHD, Autism Spectrum, Adolescent Therapy",
        location: "Online & Chicago, IL", 
        isOnlineAvailable: true,
        rating: 47, // 4.7 stars
        reviewCount: 203,
        bio: "Dr. Park focuses on neurodevelopmental differences and adolescent mental health with specialized training in ADHD and autism spectrum support.",
        yearsExperience: 10,
        profileImageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
      },
      {
        name: "Dr. Maria Santos",
        credentials: "Licensed Clinical Psychologist",
        specialties: "Eating Disorders, Body Image, Self-Esteem",
        location: "Online & Houston, TX",
        isOnlineAvailable: true,
        rating: 49, // 4.9 stars
        reviewCount: 142,
        bio: "Dr. Santos specializes in eating disorders, body image concerns, and self-esteem issues with a compassionate, evidence-based approach.",
        yearsExperience: 9,
        profileImageUrl: "https://images.unsplash.com/photo-1594824389863-f9a1bc26e58e?w=150&h=150&fit=crop&crop=face",
      },
      {
        name: "Dr. David Kim",
        credentials: "Licensed Psychiatrist", 
        specialties: "Bipolar Disorder, Medication Management, Crisis Intervention",
        location: "Online & Seattle, WA",
        isOnlineAvailable: true,
        rating: 46, // 4.6 stars
        reviewCount: 98,
        bio: "Dr. Kim provides comprehensive psychiatric care including medication management and crisis intervention with 14+ years of clinical experience.",
        yearsExperience: 14,
        profileImageUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
      },
    ];

    for (const professional of professionalsData) {
      await db.insert(professionals).values(professional).onConflictDoNothing();
    }

    console.log("Database seeded successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
    throw error;
  }
}

// Run seeding if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  seedDatabase().then(() => {
    console.log("Seeding completed");
    process.exit(0);
  }).catch((error) => {
    console.error("Seeding failed:", error);
    process.exit(1);
  });
}
