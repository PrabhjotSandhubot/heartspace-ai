import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { 
  generateEmpatheticResponse, 
  generateDailyQuote, 
  analyzeMoodPattern 
} from "./openai";
import { 
  insertMoodEntrySchema,
  insertCommunityPostSchema,
  insertCommunityReplySchema,
  insertChatSessionSchema,
  insertChatMessageSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Daily quote endpoint (public)
  app.get('/api/quote/daily', async (req, res) => {
    try {
      const quote = await generateDailyQuote();
      res.json({ quote });
    } catch (error) {
      console.error("Error generating daily quote:", error);
      res.status(500).json({ message: "Failed to generate quote" });
    }
  });

  // Mood tracking endpoints
  app.post('/api/mood', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const moodData = insertMoodEntrySchema.parse({
        ...req.body,
        userId
      });
      
      const entry = await storage.createMoodEntry(moodData);
      res.json(entry);
    } catch (error) {
      console.error("Error creating mood entry:", error);
      res.status(500).json({ message: "Failed to create mood entry" });
    }
  });

  app.get('/api/mood', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const entries = await storage.getUserMoodEntries(userId);
      res.json(entries);
    } catch (error) {
      console.error("Error fetching mood entries:", error);
      res.status(500).json({ message: "Failed to fetch mood entries" });
    }
  });

  app.get('/api/mood/analysis', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const entries = await storage.getUserMoodEntries(userId, 14);
      const validEntries = entries.filter(entry => entry.createdAt !== null).map(entry => ({
        mood: entry.mood,
        createdAt: entry.createdAt!
      }));
      const analysis = await analyzeMoodPattern(validEntries);
      res.json(analysis);
    } catch (error) {
      console.error("Error analyzing mood pattern:", error);
      res.status(500).json({ message: "Failed to analyze mood pattern" });
    }
  });

  // Community endpoints
  app.get('/api/community/groups', async (req, res) => {
    try {
      const groups = await storage.getCommunityGroups();
      res.json(groups);
    } catch (error) {
      console.error("Error fetching community groups:", error);
      res.status(500).json({ message: "Failed to fetch community groups" });
    }
  });

  app.get('/api/community/posts/:groupId', async (req, res) => {
    try {
      const { groupId } = req.params;
      const posts = await storage.getCommunityPosts(groupId);
      res.json(posts);
    } catch (error) {
      console.error("Error fetching community posts:", error);
      res.status(500).json({ message: "Failed to fetch community posts" });
    }
  });

  app.post('/api/community/posts', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const postData = insertCommunityPostSchema.parse({
        ...req.body,
        userId
      });
      
      const post = await storage.createCommunityPost(postData);
      res.json(post);
    } catch (error) {
      console.error("Error creating community post:", error);
      res.status(500).json({ message: "Failed to create community post" });
    }
  });

  app.get('/api/community/replies/:postId', async (req, res) => {
    try {
      const { postId } = req.params;
      const replies = await storage.getCommunityReplies(postId);
      res.json(replies);
    } catch (error) {
      console.error("Error fetching community replies:", error);
      res.status(500).json({ message: "Failed to fetch community replies" });
    }
  });

  app.post('/api/community/replies', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const replyData = insertCommunityReplySchema.parse({
        ...req.body,
        userId
      });
      
      const reply = await storage.createCommunityReply(replyData);
      res.json(reply);
    } catch (error) {
      console.error("Error creating community reply:", error);
      res.status(500).json({ message: "Failed to create community reply" });
    }
  });

  app.post('/api/community/posts/:postId/hearts', isAuthenticated, async (req, res) => {
    try {
      const { postId } = req.params;
      await storage.incrementPostHearts(postId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error incrementing post hearts:", error);
      res.status(500).json({ message: "Failed to increment hearts" });
    }
  });

  // AI Chat endpoints
  app.post('/api/chat/session', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const sessionData = insertChatSessionSchema.parse({
        ...req.body,
        userId
      });
      
      const session = await storage.createChatSession(sessionData);
      res.json(session);
    } catch (error) {
      console.error("Error creating chat session:", error);
      res.status(500).json({ message: "Failed to create chat session" });
    }
  });

  app.get('/api/chat/sessions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const sessions = await storage.getUserChatSessions(userId);
      res.json(sessions);
    } catch (error) {
      console.error("Error fetching chat sessions:", error);
      res.status(500).json({ message: "Failed to fetch chat sessions" });
    }
  });

  app.get('/api/chat/messages/:sessionId', isAuthenticated, async (req, res) => {
    try {
      const { sessionId } = req.params;
      const messages = await storage.getChatMessages(sessionId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching chat messages:", error);
      res.status(500).json({ message: "Failed to fetch chat messages" });
    }
  });

  app.post('/api/chat/message', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { sessionId, content, role } = req.body;
      
      // Save user message
      const userMessage = await storage.addChatMessage({
        sessionId,
        role: 'user',
        content
      });

      // Generate AI response if this is a user message
      if (role === 'user') {
        const messages = await storage.getChatMessages(sessionId);
        const conversationHistory = messages.slice(-6).map(msg => ({
          role: msg.role as 'user' | 'assistant',
          content: msg.content
        }));

        const aiResponse = await generateEmpatheticResponse(content, conversationHistory);
        
        // Save AI response
        const assistantMessage = await storage.addChatMessage({
          sessionId,
          role: 'assistant',
          content: aiResponse.response
        });

        res.json({
          userMessage,
          assistantMessage,
          aiInsights: {
            detectedMood: aiResponse.detectedMood,
            suggestedActivities: aiResponse.suggestedActivities,
            supportLevel: aiResponse.supportLevel
          }
        });
      } else {
        res.json({ userMessage });
      }
    } catch (error) {
      console.error("Error sending chat message:", error);
      res.status(500).json({ message: "Failed to send message" });
    }
  });

  // Professional directory endpoints
  app.get('/api/professionals', async (req, res) => {
    try {
      const { specialization, location } = req.query;
      const professionals = await storage.getProfessionals({
        specialization: specialization as string,
        location: location as string
      });
      res.json(professionals);
    } catch (error) {
      console.error("Error fetching professionals:", error);
      res.status(500).json({ message: "Failed to fetch professionals" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
