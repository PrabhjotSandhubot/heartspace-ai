import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface EmotionalResponse {
  response: string;
  detectedMood: number; // 1-5 scale
  suggestedActivities: string[];
  supportLevel: 'low' | 'medium' | 'high' | 'urgent';
}

export async function generateEmpatheticResponse(
  userMessage: string,
  conversationHistory: Array<{ role: 'user' | 'assistant'; content: string }> = []
): Promise<EmotionalResponse> {
  try {
    const systemPrompt = `You are Aria, a compassionate AI emotional support companion for HeartSpace. Your role is to:

1. Listen empathetically and respond with genuine care and understanding
2. Detect the user's emotional state and provide appropriate support
3. Offer gentle coping strategies and emotional validation
4. Suggest helpful activities based on their mood
5. Assess if they need urgent professional help

Always respond with warmth, avoid clinical language, and never minimize their feelings. If someone expresses thoughts of self-harm, indicate urgent support level.

Respond in JSON format with:
{
  "response": "Your empathetic response (warm, caring, supportive)",
  "detectedMood": 1-5 (1=struggling, 2=low, 3=okay, 4=good, 5=great),
  "suggestedActivities": ["activity1", "activity2", "activity3"],
  "supportLevel": "low/medium/high/urgent"
}`;

    const messages = [
      { role: "system" as const, content: systemPrompt },
      ...conversationHistory.slice(-6), // Keep last 6 messages for context
      { role: "user" as const, content: userMessage }
    ];

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages,
      response_format: { type: "json_object" },
      temperature: 0.7,
      max_tokens: 500,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      response: result.response || "I'm here to listen and support you. How are you feeling right now?",
      detectedMood: Math.max(1, Math.min(5, result.detectedMood || 3)),
      suggestedActivities: result.suggestedActivities || ["Take deep breaths", "Go for a gentle walk", "Listen to calming music"],
      supportLevel: ['low', 'medium', 'high', 'urgent'].includes(result.supportLevel) ? result.supportLevel : 'medium'
    };
  } catch (error) {
    console.error("Error generating empathetic response:", error);
    
    // Fallback response
    return {
      response: "I'm here to listen and support you. Sometimes I have trouble finding the right words, but I want you to know that your feelings are valid and you're not alone. How are you feeling right now?",
      detectedMood: 3,
      suggestedActivities: ["Take slow, deep breaths", "Write down your thoughts", "Reach out to someone you trust"],
      supportLevel: 'medium'
    };
  }
}

export async function generateDailyQuote(mood?: number): Promise<string> {
  try {
    const moodContext = mood ? `The user's current mood level is ${mood}/5. ` : '';
    
    const prompt = `${moodContext}Generate an uplifting, inspirational quote that would provide comfort and motivation for someone on their mental wellness journey. The quote should be hopeful, gentle, and encouraging. Respond with just the quote text in quotes.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.8,
      max_tokens: 100,
    });

    const quote = response.choices[0].message.content?.replace(/^"|"$/g, '') || '';
    return quote || "Every day is a new beginning. Take a deep breath and start again.";
  } catch (error) {
    console.error("Error generating daily quote:", error);
    return "You are stronger than you know, braver than you feel, and more loved than you imagine.";
  }
}

export async function analyzeMoodPattern(moodEntries: Array<{ mood: number; createdAt: Date }>): Promise<{
  trend: 'improving' | 'declining' | 'stable';
  insights: string[];
  recommendations: string[];
}> {
  try {
    const moodData = moodEntries.slice(0, 14).map(entry => ({
      mood: entry.mood,
      date: entry.createdAt.toISOString().split('T')[0]
    }));

    const prompt = `Analyze this mood data from the past 2 weeks and provide insights:
${JSON.stringify(moodData)}

Provide analysis in JSON format:
{
  "trend": "improving/declining/stable",
  "insights": ["insight1", "insight2"],
  "recommendations": ["recommendation1", "recommendation2"]
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
      temperature: 0.5,
      max_tokens: 300,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      trend: ['improving', 'declining', 'stable'].includes(result.trend) ? result.trend : 'stable',
      insights: Array.isArray(result.insights) ? result.insights : ["Your mood patterns show unique aspects of your wellness journey."],
      recommendations: Array.isArray(result.recommendations) ? result.recommendations : ["Continue tracking your mood daily for better insights."]
    };
  } catch (error) {
    console.error("Error analyzing mood pattern:", error);
    return {
      trend: 'stable',
      insights: ["Your mood tracking is helping build awareness of your emotional patterns."],
      recommendations: ["Keep up with daily mood check-ins to better understand your wellness journey."]
    };
  }
}
