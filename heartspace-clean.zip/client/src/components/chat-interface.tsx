import { useState, useEffect, useRef } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Heart, Send, Bot, User } from "lucide-react";

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  createdAt: string;
}

interface ChatSession {
  id: string;
  title: string;
  createdAt: string;
}

export function ChatInterface() {
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [message, setMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: sessions } = useQuery({
    queryKey: ["/api/chat/sessions"],
    retry: false,
  });

  const { data: messages, isLoading: messagesLoading } = useQuery({
    queryKey: ["/api/chat/messages", currentSessionId],
    enabled: !!currentSessionId,
    retry: false,
  });

  useEffect(() => {
    if (sessions && Array.isArray(sessions) && sessions.length > 0 && !currentSessionId) {
      setCurrentSessionId(sessions[0].id);
    }
  }, [sessions, currentSessionId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const createSession = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/chat/session", {
        title: "New Conversation"
      });
      return response.json();
    },
    onSuccess: (newSession) => {
      setCurrentSessionId(newSession.id);
      queryClient.invalidateQueries({ queryKey: ["/api/chat/sessions"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create new chat session.",
        variant: "destructive",
      });
    },
  });

  const sendMessage = useMutation({
    mutationFn: async (data: { sessionId: string; content: string; role: string }) => {
      const response = await apiRequest("POST", "/api/chat/message", data);
      return response.json();
    },
    onSuccess: () => {
      setMessage("");
      queryClient.invalidateQueries({ queryKey: ["/api/chat/messages", currentSessionId] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = () => {
    if (!message.trim() || !currentSessionId) return;

    sendMessage.mutate({
      sessionId: currentSessionId,
      content: message.trim(),
      role: 'user'
    });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const startNewChat = () => {
    createSession.mutate();
  };

  return (
    <div className="max-w-4xl mx-auto">
      <Card className="bg-white dark:bg-gray-800 shadow-xl overflow-hidden">
        {/* Chat Header */}
        <CardHeader className="bg-gradient-to-r from-blue-500 to-purple-600 text-white p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Avatar className="h-12 w-12 bg-white/20">
                <AvatarFallback className="bg-transparent">
                  <Bot className="h-6 w-6 text-white" />
                </AvatarFallback>
              </Avatar>
              <div>
                <h3 className="font-semibold text-lg">Aria</h3>
                <p className="text-sm opacity-90">Your compassionate AI companion</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
              <Button
                variant="outline"
                size="sm"
                onClick={startNewChat}
                disabled={createSession.isPending}
                className="bg-white/10 border-white/20 text-white hover:bg-white/20"
              >
                New Chat
              </Button>
            </div>
          </div>
        </CardHeader>

        {/* Chat Messages */}
        <CardContent className="p-0">
          <div className="h-96 overflow-y-auto p-6 space-y-4">
            {messagesLoading ? (
              <div className="flex justify-center items-center h-full">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
              </div>
            ) : messages && Array.isArray(messages) && messages.length > 0 ? (
              messages.map((msg: ChatMessage) => (
                <div key={msg.id} className={`flex items-start space-x-3 ${msg.role === 'user' ? 'flex-row-reverse space-x-reverse' : ''}`}>
                  <Avatar className="h-8 w-8 flex-shrink-0">
                    <AvatarFallback className={msg.role === 'assistant' ? 'bg-gradient-to-br from-blue-500 to-purple-600 text-white' : 'bg-gray-500 text-white'}>
                      {msg.role === 'assistant' ? <Heart className="h-4 w-4" /> : <User className="h-4 w-4" />}
                    </AvatarFallback>
                  </Avatar>
                  <div className={`rounded-2xl p-4 max-w-md ${
                    msg.role === 'user' 
                      ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-tr-md' 
                      : 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-tl-md'
                  }`}>
                    <p className="whitespace-pre-wrap">{msg.content}</p>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center text-gray-500 dark:text-gray-400 mt-8">
                <Heart className="h-12 w-12 mx-auto mb-4 text-blue-500" />
                <p className="text-lg mb-2">Hello! I'm Aria, your emotional support companion.</p>
                <p>I'm here to listen and support you. How are you feeling today?</p>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Chat Input */}
          <div className="border-t border-gray-200 dark:border-gray-700 p-6">
            <div className="flex items-center space-x-4">
              <div className="flex-1 relative">
                <Input
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Share what's on your mind..."
                  disabled={sendMessage.isPending || !currentSessionId}
                  className="pr-12 bg-gray-100 dark:bg-gray-700 border-0 rounded-full py-3 px-6"
                />
              </div>
              <Button
                onClick={handleSendMessage}
                disabled={!message.trim() || sendMessage.isPending || !currentSessionId}
                className="bg-gradient-to-r from-blue-500 to-purple-600 text-white p-3 rounded-full hover:shadow-lg transition-all duration-300"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-2 text-center">
              Your conversations are private and secure
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
