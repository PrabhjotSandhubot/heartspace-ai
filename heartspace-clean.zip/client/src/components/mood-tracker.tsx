import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";

const moodEmojis = [
  { value: 5, emoji: "😊", label: "Great", color: "text-green-500" },
  { value: 4, emoji: "🙂", label: "Good", color: "text-blue-500" },
  { value: 3, emoji: "😐", label: "Okay", color: "text-yellow-500" },
  { value: 2, emoji: "😔", label: "Low", color: "text-orange-500" },
  { value: 1, emoji: "😢", label: "Struggling", color: "text-red-500" },
];

export function MoodTracker() {
  const [selectedMood, setSelectedMood] = useState<number | null>(null);
  const [notes, setNotes] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: moodEntries, isLoading } = useQuery({
    queryKey: ["/api/mood"],
    retry: false,
  });

  const { data: moodAnalysis } = useQuery({
    queryKey: ["/api/mood/analysis"],
    retry: false,
  });

  const createMoodEntry = useMutation({
    mutationFn: async (data: { mood: number; notes?: string }) => {
      await apiRequest("POST", "/api/mood", data);
    },
    onSuccess: () => {
      toast({
        title: "Mood recorded",
        description: "Thank you for checking in with yourself today.",
      });
      setSelectedMood(null);
      setNotes("");
      queryClient.invalidateQueries({ queryKey: ["/api/mood"] });
      queryClient.invalidateQueries({ queryKey: ["/api/mood/analysis"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to record your mood. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleMoodSubmit = () => {
    if (selectedMood === null) return;
    
    createMoodEntry.mutate({
      mood: selectedMood,
      notes: notes.trim() || undefined,
    });
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-8">
          <div className="animate-pulse">
            <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded mb-4"></div>
            <div className="h-20 bg-gray-200 dark:bg-gray-700 rounded"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Mood Check-in */}
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-light text-gray-900 dark:text-white">
            How are you feeling today?
          </CardTitle>
          <p className="text-gray-600 dark:text-gray-300">
            Track your emotional wellness journey with our daily mood check-in.
          </p>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {/* Mood Selection */}
            <div className="flex flex-wrap gap-4 justify-center">
              {moodEmojis.map((mood) => (
                <button
                  key={mood.value}
                  onClick={() => setSelectedMood(mood.value)}
                  className={`flex flex-col items-center p-4 rounded-2xl border-2 transition-all duration-300 hover:scale-110 ${
                    selectedMood === mood.value
                      ? "border-blue-500 bg-blue-50 dark:bg-blue-950"
                      : "border-gray-200 dark:border-gray-700 bg-gray-100 dark:bg-gray-800 hover:border-gray-300 dark:hover:border-gray-600"
                  }`}
                >
                  <div className="text-4xl mb-2">{mood.emoji}</div>
                  <span className={`text-sm font-medium ${mood.color}`}>
                    {mood.label}
                  </span>
                </button>
              ))}
            </div>

            {/* Notes */}
            {selectedMood && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Any thoughts you'd like to share? (optional)
                  </label>
                  <Textarea
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="What's on your mind today..."
                    className="min-h-[100px]"
                  />
                </div>
                <Button
                  onClick={handleMoodSubmit}
                  disabled={createMoodEntry.isPending}
                  className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white"
                >
                  {createMoodEntry.isPending ? "Recording..." : "Record Mood"}
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Mood Insights */}
      {moodAnalysis && (
        <Card>
          <CardHeader>
            <CardTitle className="text-xl font-semibold text-gray-900 dark:text-white">
              Your Wellness Insights
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h4 className="font-medium text-gray-900 dark:text-white mb-2">
                  Recent Trend: {(moodAnalysis as any)?.trend === 'improving' ? '📈 Improving' : (moodAnalysis as any)?.trend === 'declining' ? '📉 Needs Attention' : '📊 Stable'}
                </h4>
              </div>
              
              {(moodAnalysis as any)?.insights?.length > 0 && (
                <div>
                  <h4 className="font-medium text-gray-900 dark:text-white mb-2">Insights</h4>
                  <ul className="space-y-1">
                    {(moodAnalysis as any).insights.map((insight: string, index: number) => (
                      <li key={index} className="text-gray-600 dark:text-gray-300 text-sm">
                        • {insight}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {(moodAnalysis as any)?.recommendations?.length > 0 && (
                <div>
                  <h4 className="font-medium text-gray-900 dark:text-white mb-2">Recommendations</h4>
                  <ul className="space-y-1">
                    {(moodAnalysis as any).recommendations.map((rec: string, index: number) => (
                      <li key={index} className="text-gray-600 dark:text-gray-300 text-sm">
                        • {rec}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
