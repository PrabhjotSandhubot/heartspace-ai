import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Heart, MessageCircle, Users, Send } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface CommunityGroup {
  id: string;
  name: string;
  description: string;
  category: string;
  memberCount: number;
}

interface CommunityPost {
  id: string;
  content: string;
  isAnonymous: boolean;
  heartCount: number;
  replyCount: number;
  createdAt: string;
}

const categoryColors: Record<string, string> = {
  anxiety: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  grief: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200",
  motivation: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
  relationships: "bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200",
  depression: "bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200",
};

export function CommunityGroups() {
  const [selectedGroup, setSelectedGroup] = useState<string | null>(null);
  const [newPost, setNewPost] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: groups, isLoading: groupsLoading } = useQuery({
    queryKey: ["/api/community/groups"],
    retry: false,
  });

  const { data: posts, isLoading: postsLoading } = useQuery({
    queryKey: ["/api/community/posts", selectedGroup],
    enabled: !!selectedGroup,
    retry: false,
  });

  const createPost = useMutation({
    mutationFn: async (data: { groupId: string; content: string; isAnonymous: boolean }) => {
      await apiRequest("POST", "/api/community/posts", data);
    },
    onSuccess: () => {
      toast({
        title: "Post shared",
        description: "Your post has been shared with the community.",
      });
      setNewPost("");
      queryClient.invalidateQueries({ queryKey: ["/api/community/posts", selectedGroup] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to share your post. Please try again.",
        variant: "destructive",
      });
    },
  });

  const likePost = useMutation({
    mutationFn: async (postId: string) => {
      await apiRequest("POST", `/api/community/posts/${postId}/hearts`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/community/posts", selectedGroup] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
    },
  });

  const handleCreatePost = () => {
    if (!newPost.trim() || !selectedGroup) return;

    createPost.mutate({
      groupId: selectedGroup,
      content: newPost.trim(),
      isAnonymous: true, // Default to anonymous for privacy
    });
  };

  if (groupsLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[...Array(6)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded mb-4"></div>
              <div className="h-20 bg-gray-200 dark:bg-gray-700 rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Groups Grid */}
      {!selectedGroup && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.isArray(groups) && groups.map((group: CommunityGroup) => (
            <Card
              key={group.id}
              className="hover:shadow-lg transition-all duration-300 cursor-pointer"
              onClick={() => setSelectedGroup(group.id)}
            >
              <CardContent className="p-6">
                <div className="flex items-center space-x-4 mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                    <Users className="text-white h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg text-gray-900 dark:text-white">
                      {group.name}
                    </h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {group.memberCount.toLocaleString()} members
                    </p>
                  </div>
                </div>
                <p className="text-gray-700 dark:text-gray-300 mb-4 line-clamp-2">
                  {group.description}
                </p>
                <div className="flex items-center justify-between">
                  <Badge className={categoryColors[group.category] || "bg-gray-100 text-gray-800"}>
                    {group.category}
                  </Badge>
                  <Button size="sm" className="bg-blue-500 hover:bg-blue-600 text-white">
                    Join Discussion
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Selected Group Discussion */}
      {selectedGroup && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-semibold text-gray-900 dark:text-white">
              {Array.isArray(groups) ? groups.find((g: CommunityGroup) => g.id === selectedGroup)?.name : ''}
            </h2>
            <Button
              variant="outline"
              onClick={() => setSelectedGroup(null)}
            >
              Back to Groups
            </Button>
          </div>

          {/* New Post Form */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Share with the Community</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Textarea
                  value={newPost}
                  onChange={(e) => setNewPost(e.target.value)}
                  placeholder="Share your thoughts, experiences, or offer support to others..."
                  className="min-h-[100px]"
                />
                <div className="flex items-center justify-between">
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Posts are anonymous by default to protect your privacy
                  </p>
                  <Button
                    onClick={handleCreatePost}
                    disabled={!newPost.trim() || createPost.isPending}
                    className="bg-gradient-to-r from-blue-500 to-purple-600 text-white"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    {createPost.isPending ? "Sharing..." : "Share"}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Posts */}
          <div className="space-y-6">
            {postsLoading ? (
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardContent className="p-6">
                      <div className="h-20 bg-gray-200 dark:bg-gray-700 rounded"></div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : posts && Array.isArray(posts) && posts.length > 0 ? (
              posts.map((post: CommunityPost) => (
                <Card key={post.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <Avatar className="h-10 w-10">
                        <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white">
                          A
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <span className="font-medium text-gray-900 dark:text-white">
                            Anonymous
                          </span>
                          <span className="text-sm text-gray-500 dark:text-gray-400">
                            • {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
                          </span>
                        </div>
                        <p className="text-gray-700 dark:text-gray-300 mb-4 whitespace-pre-wrap">
                          {post.content}
                        </p>
                        <div className="flex items-center space-x-6 text-sm text-gray-500 dark:text-gray-400">
                          <button
                            onClick={() => likePost.mutate(post.id)}
                            className="flex items-center space-x-1 hover:text-red-500 transition-colors"
                          >
                            <Heart className="h-4 w-4" />
                            <span>{post.heartCount} hearts</span>
                          </button>
                          <button className="flex items-center space-x-1 hover:text-blue-500 transition-colors">
                            <MessageCircle className="h-4 w-4" />
                            <span>{post.replyCount} replies</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card>
                <CardContent className="p-8 text-center">
                  <Users className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                  <p className="text-gray-600 dark:text-gray-400">
                    No posts yet. Be the first to share with this community!
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
