import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Star, MapPin, Clock, MessageCircle } from "lucide-react";
import { useState } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface Professional {
  id: string;
  name: string;
  credentials: string;
  specialties: string;
  location: string;
  isOnlineAvailable: boolean;
  rating: number;
  reviewCount: number;
  profileImageUrl?: string;
  bio?: string;
  yearsExperience?: number;
}

export function ProfessionalDirectory() {
  const [specialization, setSpecialization] = useState<string>("All Specializations");
  const [location, setLocation] = useState<string>("Online Sessions");

  const { data: professionals, isLoading } = useQuery({
    queryKey: ["/api/professionals", { specialization, location }],
    retry: false,
  });

  if (isLoading) {
    return (
      <div className="space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-6 bg-gray-50 dark:bg-gray-800 rounded-2xl animate-pulse">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-10 bg-gray-200 dark:bg-gray-700 rounded"></div>
          ))}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-20 bg-gray-200 dark:bg-gray-700 rounded mb-4"></div>
                <div className="h-40 bg-gray-200 dark:bg-gray-700 rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Search and Filters */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-gray-700 dark:to-gray-800">
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Specialization
              </label>
              <Select value={specialization} onValueChange={setSpecialization}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="All Specializations">All Specializations</SelectItem>
                  <SelectItem value="Anxiety & Depression">Anxiety & Depression</SelectItem>
                  <SelectItem value="Trauma & PTSD">Trauma & PTSD</SelectItem>
                  <SelectItem value="Relationship Issues">Relationship Issues</SelectItem>
                  <SelectItem value="Grief & Loss">Grief & Loss</SelectItem>
                  <SelectItem value="Addiction Recovery">Addiction Recovery</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Location
              </label>
              <Select value={location} onValueChange={setLocation}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Online Sessions">Online Sessions</SelectItem>
                  <SelectItem value="New York, NY">New York, NY</SelectItem>
                  <SelectItem value="Los Angeles, CA">Los Angeles, CA</SelectItem>
                  <SelectItem value="Chicago, IL">Chicago, IL</SelectItem>
                  <SelectItem value="Houston, TX">Houston, TX</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Availability
              </label>
              <Select defaultValue="This Week">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="This Week">This Week</SelectItem>
                  <SelectItem value="Next Week">Next Week</SelectItem>
                  <SelectItem value="This Month">This Month</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white">
                Search
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Professionals Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {professionals && Array.isArray(professionals) && professionals.length > 0 ? (
          professionals.map((professional: Professional) => (
            <Card key={professional.id} className="hover:shadow-xl transition-all duration-300">
              <CardContent className="p-6">
                <div className="text-center mb-4">
                  <Avatar className="w-20 h-20 mx-auto mb-4">
                    <AvatarImage
                      src={professional.profileImageUrl}
                      alt={professional.name}
                    />
                    <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white text-lg">
                      {professional.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <h3 className="font-semibold text-lg text-gray-900 dark:text-white">
                    {professional.name}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400 text-sm">
                    {professional.credentials}
                  </p>
                </div>

                <div className="space-y-2 mb-4">
                  <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                    <Star className="h-4 w-4 text-yellow-400 mr-2" />
                    <span>
                      {(professional.rating / 10).toFixed(1)} ({professional.reviewCount} reviews)
                    </span>
                  </div>
                  <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                    <MapPin className="h-4 w-4 mr-2" />
                    <span>{professional.location}</span>
                  </div>
                  <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                    <Clock className="h-4 w-4 mr-2" />
                    <span>Available this week</span>
                  </div>
                </div>

                <div className="mb-4">
                  <p className="text-sm text-gray-700 dark:text-gray-300 line-clamp-3">
                    {professional.bio || professional.specialties}
                  </p>
                </div>

                <div className="flex flex-wrap gap-2 mb-4">
                  {professional.specialties.split(',').slice(0, 2).map((specialty, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {specialty.trim()}
                    </Badge>
                  ))}
                </div>

                <div className="flex space-x-2">
                  <Button className="flex-1 bg-blue-500 hover:bg-blue-600 text-white">
                    Book Session
                  </Button>
                  <Button variant="outline" size="icon">
                    <MessageCircle className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        ) : (
          <div className="col-span-full text-center py-12">
            <p className="text-gray-600 dark:text-gray-400">
              No professionals found matching your criteria. Try adjusting your filters.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
