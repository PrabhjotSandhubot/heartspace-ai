import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Heart, MessageCircle, Users, Sparkles, Quote } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export default function Landing() {
  const { data: dailyQuote } = useQuery({
    queryKey: ["/api/quote/daily"],
    retry: false,
  });

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background with overlay */}
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-br from-blue-100/30 to-purple-100/30 dark:from-gray-900/50 dark:to-gray-800/50"></div>
        </div>

        <div className="relative z-10 max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <div className="animate-float">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-light text-gray-900 dark:text-white mb-6 leading-tight">
              Welcome to Your
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-500 to-purple-600 font-medium block">
                Safe Haven
              </span>
            </h1>
          </div>
          
          <p className="text-xl sm:text-2xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto leading-relaxed">
            A compassionate space where you're never alone. Find support, connect with others, and discover tools for emotional wellness.
          </p>

          {/* Quick Access Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
            <Button
              size="lg"
              onClick={() => window.location.href = "/api/login"}
              className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-8 py-4 rounded-full font-medium text-lg hover:shadow-lg transform hover:scale-105 transition-all duration-300 flex items-center space-x-3"
            >
              <MessageCircle className="h-5 w-5" />
              <span>Get Started</span>
            </Button>
            <Button
              variant="outline"
              size="lg"
              onClick={() => window.location.href = "/api/login"}
              className="px-8 py-4 rounded-full font-medium text-lg border-2 transition-all duration-300 flex items-center space-x-3"
            >
              <Users className="h-5 w-5" />
              <span>Join Community</span>
            </Button>
          </div>

          {/* Daily Quote Card */}
          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-md max-w-2xl mx-auto shadow-lg border border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-center mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-pink-400 rounded-full flex items-center justify-center">
                  <Quote className="text-white h-5 w-5" />
                </div>
              </div>
              <p className="text-lg text-gray-700 dark:text-gray-300 italic text-center mb-3">
                "{(dailyQuote as any)?.quote || 'Every day is a new beginning. Take a deep breath and start again.'}"
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400 text-center">Today's Inspiration</p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-light text-gray-900 dark:text-white mb-4">
              How <span className="text-blue-600 dark:text-blue-400 font-medium">HeartSpace</span> Supports You
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Discover the tools and communities designed to nurture your emotional wellness journey.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* AI Companion */}
            <Card className="hover:shadow-lg transition-all duration-300">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <MessageCircle className="text-white h-8 w-8" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">AI Companion</h3>
                <p className="text-gray-600 dark:text-gray-300 text-sm">
                  Chat with Aria, your empathetic AI companion available 24/7 for emotional support.
                </p>
              </CardContent>
            </Card>

            {/* Community Support */}
            <Card className="hover:shadow-lg transition-all duration-300">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Users className="text-white h-8 w-8" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Safe Community</h3>
                <p className="text-gray-600 dark:text-gray-300 text-sm">
                  Connect anonymously with others who understand your journey in supportive groups.
                </p>
              </CardContent>
            </Card>

            {/* Self-Care Tools */}
            <Card className="hover:shadow-lg transition-all duration-300">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Sparkles className="text-white h-8 w-8" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Self-Care Hub</h3>
                <p className="text-gray-600 dark:text-gray-300 text-sm">
                  Access meditation, journaling, mood tracking, and wellness activities.
                </p>
              </CardContent>
            </Card>

            {/* Professional Help */}
            <Card className="hover:shadow-lg transition-all duration-300">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-pink-500 to-pink-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Heart className="text-white h-8 w-8" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Professional Care</h3>
                <p className="text-gray-600 dark:text-gray-300 text-sm">
                  Find and connect with certified mental health professionals when you need them.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl sm:text-4xl font-light text-gray-900 dark:text-white mb-6">
            Your mental health journey starts here
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-300 mb-8">
            Join thousands who have found support, healing, and hope through HeartSpace.
          </p>
          <Button
            size="lg"
            onClick={() => window.location.href = "/api/login"}
            className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-8 py-4 rounded-full font-medium text-lg hover:shadow-lg transform hover:scale-105 transition-all duration-300"
          >
            Begin Your Journey
          </Button>
        </div>
      </section>
    </div>
  );
}
