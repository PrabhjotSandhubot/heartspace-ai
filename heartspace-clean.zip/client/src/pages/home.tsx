import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MoodTracker } from "@/components/mood-tracker";
import { Heart, MessageCircle, Users, Sparkles, Quote } from "lucide-react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";

export default function Home() {
  const { isAuthenticated, isLoading, user } = useAuth();
  const { toast } = useToast();

  const { data: dailyQuote } = useQuery({
    queryKey: ["/api/quote/daily"],
    retry: false,
  });

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Header */}
        <div className="text-center mb-12">
          <h1 className="text-3xl sm:text-4xl font-light text-gray-900 dark:text-white mb-4">
            Welcome back{(user as any)?.firstName ? `, ${(user as any).firstName}` : ''}! 
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-500 to-purple-600 font-medium">
              How are you feeling today?
            </span>
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Your safe space for emotional wellness is ready whenever you need it.
          </p>
        </div>

        {/* Daily Quote */}
        <Card className="mb-8 bg-white/80 dark:bg-gray-800/80 backdrop-blur-md">
          <CardContent className="p-6">
            <div className="flex items-center justify-center mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-pink-400 rounded-full flex items-center justify-center">
                <Quote className="text-white h-5 w-5" />
              </div>
            </div>
            <p className="text-lg text-gray-700 dark:text-gray-300 italic text-center mb-3">
              "{(dailyQuote as any)?.quote || 'Every day is a new beginning. Take a deep breath and start again.'}"
            </p>
            <p className="text-sm text-gray-500 dark:text-gray-400 text-center">Today's Inspiration</p>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content - Mood Tracker */}
          <div className="lg:col-span-2">
            <MoodTracker />
          </div>

          {/* Sidebar - Quick Actions */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-gray-900 dark:text-white">
                  Quick Actions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Link href="/ai-chat">
                  <Button className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white justify-start">
                    <MessageCircle className="mr-3 h-4 w-4" />
                    Talk to Aria
                  </Button>
                </Link>
                <Link href="/community">
                  <Button variant="outline" className="w-full justify-start">
                    <Users className="mr-3 h-4 w-4" />
                    Browse Community
                  </Button>
                </Link>
                <Link href="/self-care">
                  <Button variant="outline" className="w-full justify-start">
                    <Sparkles className="mr-3 h-4 w-4" />
                    Self-Care Activities
                  </Button>
                </Link>
                <Link href="/professionals">
                  <Button variant="outline" className="w-full justify-start">
                    <Heart className="mr-3 h-4 w-4" />
                    Find Professional Help
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Support Resources */}
            <Card>
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-gray-900 dark:text-white">
                  Crisis Support
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4">
                  <div className="flex items-center space-x-3 mb-3">
                    <div className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center">
                      <Heart className="text-white h-4 w-4" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-red-700 dark:text-red-300">Need immediate help?</h4>
                    </div>
                  </div>
                  <p className="text-red-600 dark:text-red-400 text-sm mb-3">
                    If you're having thoughts of self-harm or suicide, please reach out immediately.
                  </p>
                  <Button
                    size="sm"
                    className="bg-red-500 hover:bg-red-600 text-white w-full"
                    onClick={() => window.open('tel:988', '_self')}
                  >
                    Call 988 - Crisis Lifeline
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Privacy Reminder */}
            <Card>
              <CardContent className="p-4">
                <div className="text-center">
                  <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-2">
                    <Heart className="text-white h-4 w-4" />
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    Your privacy is protected. All conversations and data are encrypted and secure.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
