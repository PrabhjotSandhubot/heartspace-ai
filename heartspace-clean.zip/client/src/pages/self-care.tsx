import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MoodTracker } from "@/components/mood-tracker";
import { Leaf, PenTool, Wind, Gamepad2 } from "lucide-react";

export default function SelfCare() {
  const { isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl sm:text-4xl font-light text-gray-900 dark:text-white mb-4">
            Self-Care <span className="text-green-600 dark:text-green-400 font-medium">Wellness Hub</span>
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Discover tools and activities designed to nurture your mental wellness and build resilience.
          </p>
        </div>

        <div className="space-y-8">
          {/* Mood Tracker */}
          <MoodTracker />

          {/* Self-Care Activities */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Meditation */}
            <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 hover:shadow-lg transition-all duration-300">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mb-4">
                  <Leaf className="text-white h-8 w-8" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  Guided Meditation
                </h3>
                <p className="text-gray-600 dark:text-gray-300 text-sm mb-4">
                  Find peace with our collection of calming guided meditations.
                </p>
                <Button variant="link" className="text-blue-600 dark:text-blue-400 p-0">
                  Start Session →
                </Button>
              </CardContent>
            </Card>

            {/* Journaling */}
            <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20 hover:shadow-lg transition-all duration-300">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mb-4">
                  <PenTool className="text-white h-8 w-8" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  Reflection Journal
                </h3>
                <p className="text-gray-600 dark:text-gray-300 text-sm mb-4">
                  Express your thoughts with guided journaling prompts.
                </p>
                <Button variant="link" className="text-purple-600 dark:text-purple-400 p-0">
                  Write Now →
                </Button>
              </CardContent>
            </Card>

            {/* Breathing */}
            <Card className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20 hover:shadow-lg transition-all duration-300">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center mb-4">
                  <Wind className="text-white h-8 w-8" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  Breathing Exercises
                </h3>
                <p className="text-gray-600 dark:text-gray-300 text-sm mb-4">
                  Practice mindful breathing techniques for instant calm.
                </p>
                <Button variant="link" className="text-green-600 dark:text-green-400 p-0">
                  Breathe →
                </Button>
              </CardContent>
            </Card>

            {/* Activities */}
            <Card className="bg-gradient-to-br from-pink-50 to-pink-100 dark:from-pink-900/20 dark:to-pink-800/20 hover:shadow-lg transition-all duration-300">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-gradient-to-br from-pink-500 to-pink-600 rounded-2xl flex items-center justify-center mb-4">
                  <Gamepad2 className="text-white h-8 w-8" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  Fun Activities
                </h3>
                <p className="text-gray-600 dark:text-gray-300 text-sm mb-4">
                  Engage in uplifting games and creative challenges.
                </p>
                <Button variant="link" className="text-pink-600 dark:text-pink-400 p-0">
                  Play →
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Wellness Tips */}
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl font-semibold text-gray-900 dark:text-white">
                Daily Wellness Tips
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-medium text-gray-900 dark:text-white">Mindfulness Practices</h4>
                  <ul className="space-y-2 text-gray-600 dark:text-gray-300">
                    <li>• Take 5 deep breaths when feeling overwhelmed</li>
                    <li>• Practice gratitude by noting 3 positive things daily</li>
                    <li>• Try the 5-4-3-2-1 grounding technique</li>
                    <li>• Set boundaries to protect your mental energy</li>
                  </ul>
                </div>
                <div className="space-y-4">
                  <h4 className="font-medium text-gray-900 dark:text-white">Self-Compassion Reminders</h4>
                  <ul className="space-y-2 text-gray-600 dark:text-gray-300">
                    <li>• It's okay to have difficult emotions</li>
                    <li>• Progress isn't always linear</li>
                    <li>• You deserve kindness, especially from yourself</li>
                    <li>• Small steps count as progress</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
